#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 20:21:17 2017

@author: rditljtd
"""

import numpy as np
from scipy import misc
from scipy import sparse as sps
import matplotlib.pyplot as plt

# Load the labels for the training set
train_labels = np.loadtxt('train-labels.txt',dtype=int)
# Get the number of training examples from the number of
# labels
numTrainDocs = train_labels.shape[0]
# This is how many words we have in our dictionary
numTokens = 2500
# Load the training set feature information
M = np.loadtxt('train-features.txt',dtype=int)
# Create matrix of training data
train_matrix = sps.csr_matrix((M[:,2], (M[:,0], M[:,1])),shape=(numTrainDocs,numTokens))

theta_y = (sum(x == 1 for x in train_labels))/(numTrainDocs*(1.0))
print theta_y
print sum(x == 1 for x in train_labels)